# We loaded necessary libraries
library(dplyr)
library(ggplot2)
library(glmnet)
library(gridExtra)
library(caret)
library(shiny)
library(wordcloud2)
library(leaflet)
library(shinyWidgets)

# Defined server logic
server <- function(input, output, session) {

  
  # Created the dataset with popular songs, the origin country of the artist, year of the song publication and genre of the song
  popular_songs <- data.frame(
    country = c("Sweden", "UK", "USA", "Canada", "France", "Germany", "Italy", "Australia", "Brazil"),
    artist = c("ABBA", "The Beatles", "Elvis Presley", "Celine Dion", "Edith Piaf", "Scorpions", "Luciano Pavarotti", "AC/DC", "Gilberto Gil"),
    song = c("Chiquitita", "Hey Jude", "Can't Help Falling in Love", "My Heart Will Go On", "La Vie en Rose", "Wind of Change", "Nessun Dorma", "Highway to Hell", "Aquele Abraço"),
    genre = c("Pop", "Rock", "Rock", "Pop", "Chanson", "Rock", "Classical", "Rock", "MPB"),
    year = c(1979, 1968, 1961, 1997, 1947, 1990, 1926, 1979, 1969),
    lat = c(60.1282, 55.3781, 37.0902, 56.1304, 46.6034, 51.1657, 41.8719, -25.2744, -14.2350),
    lng = c(18.6435, -3.4360, -95.7129, -106.3468, 2.2137, 10.4515, 12.5674, 133.7751, -51.9253)
  )
  
  
  
  observe({
    updateCheckboxGroupInput(session, "selected_genres", 
                             choices = unique(most_popular_genre$Most_Popular_Genre), 
                             selected = unique(most_popular_genre$Most_Popular_Genre))
  })
  
  # Then, we rendered the plot for Most Popular Genre's Average Popularity Over the Past 7 Decades
  filtered_data <- reactive({
    req(input$selected_genres, input$popularity_range, input$decade_range)
    most_popular_genre %>%
      filter(Most_Popular_Genre %in% input$selected_genres,
             Most_Popular_Genre_Avg_Popularity >= input$popularity_range[1],
             Most_Popular_Genre_Avg_Popularity <= input$popularity_range[2],
             Decade >= input$decade_range[1],
             Decade <= input$decade_range[2])
  })
  
  output$popularityPlot <- renderPlot({
    data <- filtered_data()
    req(nrow(data) > 0)
    ggplot(data, aes(x = Decade, y = Most_Popular_Genre_Avg_Popularity, color = Most_Popular_Genre)) +
      geom_segment(aes(xend = Decade + 10, yend = Most_Popular_Genre_Avg_Popularity), size = 4) +
      labs(title = "Most Popular Genre's Average Popularity Over the Past 7 Decades",
           x = "Decade",
           y = "Average Popularity",
           color = "Genre") +
      scale_x_continuous(breaks = seq(min(data$Decade), max(data$Decade) + 10, by = 10), 
                         limits = c(min(data$Decade), 2020)) +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),
            plot.title = element_text(size = 12, face = "bold", hjust = 0.5))
  })
  
  # After, we rendered the plot for Average Danceability Over the Years
  filtered_danceability_data <- reactive({
    req(input$year_range, input$danceability_range)
    average_danceability_per_year %>%
      filter(Year >= input$year_range[1],
             Year <= input$year_range[2],
             Average_Danceability >= input$danceability_range[1],
             Average_Danceability <= input$danceability_range[2])
  })
  
  output$danceabilityPlot <- renderPlot({
    data <- filtered_danceability_data()
    req(nrow(data) > 0)
    
    plot <- ggplot(data, aes(x = Year, y = Average_Danceability)) +
      geom_line(color = "#0082C2", size = 0.8) + 
      labs(title = "Average Danceability Over the Years",
           x = "Year",
           y = "Average Danceability") +
      scale_x_continuous(breaks = seq(1950, 2020, by = 10)) + 
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1, size = 10),  
        axis.text.y = element_text(size = 10),  
        plot.title = element_text(size = 12, face = "bold", hjust = 0.5), 
        panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray90"),
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray60"),
        panel.border = element_rect(color = "gray60", fill = NA, size = 0.5))
    
    if (input$log_scale) {
      plot <- plot + scale_y_log10()
    }
    
    plot
  })
  

  regression_data <- reactive({
    req(cleaned_spoty)
    cleaned_spoty$Decade <- as.factor(cleaned_spoty$Decade)
    X <- model.matrix(Danceability ~ Decade, data = cleaned_spoty)[, -1]
    y <- cleaned_spoty$Danceability
    list(X = X, y = y)
  })

  #Reactive expression to prepare data for  Lasso Regression
  lasso_model <- reactive({
    data <- regression_data()
    set.seed(123)
    train_size <- input$train_size / 100
    trainIndex <- createDataPartition(data$y, p = train_size, list = FALSE)
    X_train <- data$X[trainIndex, ]
    X_test <- data$X[-trainIndex, ]
    y_train <- data$y[trainIndex]
    y_test <- data$y[-trainIndex]
    
    model <- cv.glmnet(X_train, y_train, alpha = 1)
    best_lambda <- model$lambda.min
    
    predictions <- predict(model, s = best_lambda, newx = X_test)
    mse <- mean((predictions - y_test)^2)
    coefficients <- coef(model, s = best_lambda)
    
    list(model = model, mse = mse, coefficients = coefficients, lambda = best_lambda)
  })
  
  output$lassoResults <- renderPrint({
    model <- lasso_model()
    cat("Lasso Regression MSE:", model$mse, "\n\n")
    cat("Lasso Regression Coefficients:\n")
    print(model$coefficients)
  })
  # Render the Lasso Regression plot
  output$lassoPlot <- renderPlot({
    model <- lasso_model()$model
    plot(model)
  })
  
  output$interpretationTable <- renderTable({
    model <- lasso_model()
    as.data.frame(as.matrix(model$coefficients))
  })
  # Reactive expression to prepare data for Ridge Regression
  ridge_data <- reactive({
    cleaned_spoty %>%
      select(`Beats Per Minute (BPM)`, Danceability, Popularity) %>%
      na.omit()
  })
  
  # Render the Ridge Regression plot
  output$ridgePlot <- renderPlot({
    data <- ridge_data()
    x <- as.matrix(data %>% select(`Beats Per Minute (BPM)`, Danceability))
    y <- data$Popularity
    
    lambdas <- exp(seq(input$lambda_range[1], input$lambda_range[2], length.out = 100))
    fit <- cv.glmnet(x, y, alpha = 0, lambda = lambdas)
    
    plot(fit)
  })
  
  # Reactive text for selected lambda range
  output$selected_lambda <- renderText({
    paste("Selected log(lambda) range: [", input$lambda_range[1], ", ", input$lambda_range[2], "]", sep = "")
  })
  
  # Reactive table for Ridge Regression coefficients
  output$ridge_coefficients <- renderTable({
    data <- ridge_data()
    x <- as.matrix(data %>% select(`Beats Per Minute (BPM)`, Danceability))
    y <- data$Popularity
    
    lambda_value <- exp(input$lambda_range[2])
    fit <- glmnet(x, y, alpha = 0, lambda = lambda_value)
    
    coef_df <- as.data.frame(as.matrix(coef(fit)))
    colnames(coef_df) <- "Coefficients"
    coef_df$Features <- rownames(coef_df)
    coef_df
  })
  
  # Reactive text for Ridge Regression interpretation
  output$ridge_interpretation <- renderText({
    data <- ridge_data()
    x <- as.matrix(data %>% select(`Beats Per Minute (BPM)`, Danceability))
    y <- data$Popularity
    
    lambda_value <- exp(input$lambda_range[2])
    fit <- glmnet(x, y, alpha = 0, lambda = lambda_value)
    
    coef_df <- as.data.frame(as.matrix(coef(fit)))
    colnames(coef_df) <- "Coefficients"
    coef_df$Features <- rownames(coef_df)
    
    interpretation <- paste("At the chosen lambda value (lambda = ", round(lambda_value, 2), "), the coefficients for the features are as follows:\n",
                            paste(coef_df$Features, ": ", round(coef_df$Coefficients, 2), collapse = "\n"),
                            sep = "")
    interpretation
  })

  # Render interactive map with popular songs
  output$map <- renderLeaflet({
    leaflet(popular_songs) %>%
      addTiles() %>%
      setView(lng = 0, lat = 0, zoom = 2) %>%
      addMarkers(~lng, ~lat, popup = ~paste(artist, "-", song))
  })
  
  # Reactive text for the popular song caption
  output$popular_song_caption <- renderText({
    req(input$map_marker_click)
    marker <- input$map_marker_click
    selected_country <- popular_songs %>% filter(lat == marker$lat, lng == marker$lng)
    paste("In", selected_country$country, "the artist", selected_country$artist, "and song", selected_country$song, "is very popular. The genre is", selected_country$genre, "and it was released in the year", selected_country$year, ".")
  })
}
  