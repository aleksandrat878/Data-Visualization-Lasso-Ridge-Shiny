# Define UI for application
library(shiny)
library(dplyr)
library(ggplot2)
library(glmnet)
library(wordcloud2)
library(leaflet)
library(shinyWidgets)

ui <- fluidPage(
  titlePanel("Spotify Music Vibe Analysis"),
  sidebarLayout(
    sidebarPanel(
      tabsetPanel(
        tabPanel("Genres over decades",
                 checkboxGroupInput("selected_genres", "Select Genres:", choices = NULL),
                 sliderInput("popularity_range", "Average Popularity Range:", min = 70, max = 90, value = c(70, 90)),
                 sliderInput("decade_range", "Decade Range:", min = 1950, max = 2020, value = c(1950, 2020), step = 10)
        ),
        tabPanel("Danceability over years",
                 checkboxInput("log_scale", "Logarithmic Scale", value = FALSE),
                 sliderInput("year_range", "Year Range:", min = 1950, max = 2020, value = c(1950, 2020), step = 1),
                 sliderInput("danceability_range", "Average Danceability Range:", min = 30, max = 65, value = c(30, 65), step = 1)
        ),
        tabPanel("Ridge Regression",
                 sliderInput("lambda_range", "Log(Lambda) Range:", min = -2, max = 6, value = c(-2, 6), step = 0.1),
                 textOutput("selected_lambda"),
                 tableOutput("ridge_coefficients"),
                 textOutput("ridge_interpretation")
        ),
        tabPanel("LASSO Regression",
                 p("LASSO Regression Settings:"),
                 sliderInput("train_size", "Training Set Size (%)", min = 50, max = 90, value = 70, step = 5)
        ),
  
        tabPanel("Interactive Map",
                 leafletOutput("map"),
                 textOutput("popular_song_caption")  # Reactive text output for the caption
        ),
      )
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Genres over decades", plotOutput("popularityPlot")),
        tabPanel("Danceability over years", plotOutput("danceabilityPlot")),
        tabPanel("Ridge Regression", plotOutput("ridgePlot")),
        tabPanel("LASSO Regression", 
                 verbatimTextOutput("lassoResults"), 
                 plotOutput("lassoPlot")),
        
        
      )
    )
  )
)


