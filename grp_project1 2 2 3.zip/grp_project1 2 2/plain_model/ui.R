ui <- fluidPage(
  titlePanel(
    div(
      h1("Spotify Music Vibe Analysis"),
      h4("This application analyzes the consistency of music vibes, specifically the danceability of songs, over several decades using Spotify's Top 2000 dataset. It provides interactive visualizations and regression analyses to explore trends in music characteristics over time.")
    )
  ),
  sidebarLayout(
    sidebarPanel(
      h4("Filter Options graph 1"),
      checkboxGroupInput("selected_genres", "Select Genres:", choices = NULL),
      sliderInput("popularity_range", "Average Popularity Range:", min = 70, max = 90, value = c(70, 90)),
      sliderInput("decade_range", "Decade Range:", min = 1950, max = 2020, value = c(1950, 2020), step = 10),
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Genres over decades",
                 plotOutput("popularityPlot")),
        tabPanel("Danceability over years",
                 plotOutput("danceabilityPlot"))
      )
    )
  )
)
