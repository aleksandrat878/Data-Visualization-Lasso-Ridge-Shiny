library(shiny)
library(ggplot2)
library(dplyr)

# Define server logic
server <- function(input, output, session) {
  
  # Update the choices for checkboxGroupInput based on the available genres
  observe({
    updateCheckboxGroupInput(session, "selected_genres", 
                             choices = unique(most_popular_genre$Most_Popular_Genre), 
                             selected = unique(most_popular_genre$Most_Popular_Genre))
  })
  
  # Reactive expression to filter data based on user input for popularity
  filtered_data <- reactive({
    most_popular_genre %>%
      filter(Most_Popular_Genre %in% input$selected_genres,
             Most_Popular_Genre_Avg_Popularity >= input$popularity_range[1],
             Most_Popular_Genre_Avg_Popularity <= input$popularity_range[2],
             Decade >= input$decade_range[1],
             Decade <= input$decade_range[2])
  })
  
  # Render the plot for Most Popular Genre's Average Popularity Over the Past 7 Decades
  output$popularityPlot <- renderPlot({
    ggplot(filtered_data(), aes(x = Decade, y = Most_Popular_Genre_Avg_Popularity, color = Most_Popular_Genre)) +
      geom_segment(aes(xend = Decade + 10, yend = Most_Popular_Genre_Avg_Popularity), size = 4) +
      labs(title = "Most Popular Genre's Average Popularity Over the Past 7 Decades",
           x = "Decade",
           y = "Average Popularity",
           color = "Genre") +
      scale_x_continuous(breaks = seq(min(most_popular_genre$Decade), max(most_popular_genre$Decade) + 10, by = 10), 
                         limits = c(min(most_popular_genre$Decade), 2020)) +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),
            plot.title = element_text(size = 12, face = "bold", hjust = 0.5))
  })
  
  
  # Render the plot for Average Danceability Over the Years
  output$danceabilityPlot <- renderPlot({
    average_danceability_per_year <- cleaned_spoty %>%
      group_by(Year) %>%
      summarise(Average_Danceability = mean(Danceability, na.rm = TRUE))
    
    ggplot(average_danceability_per_year, aes(x = Year, y = Average_Danceability)) +
      geom_line(color = "#0082C2", size = 0.8) + 
      labs(title = "Average Danceability Over the Years",
           x = "Year",
           y = "Average Danceability") +
      scale_x_continuous(breaks = seq(1950, 2020, by = 10)) + 
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1, size = 10),  
        axis.text.y = element_text(size = 10),  
        plot.title = element_text(size = 12, face = "bold", hjust = 0.5), 
        panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray90"),
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray60"),
        panel.border = element_rect(color = "gray60", fill = NA, size = 0.5))
    
  })
}
